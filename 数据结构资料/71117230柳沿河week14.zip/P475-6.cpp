#include <iostream>
#include <stack>

using namespace std;

typedef int K;
typedef char E;
struct Pair
{
	K first;

	E second;

	Pair(const K& k = 0, const E& e = ' ') { first = k; second = e; }
	
};

//����������ǰ������
class BST;

//���ڵ㶨��
class TreeNode {
	friend class BST;
private:
	Pair data;
	TreeNode *leftChild, *rightChild;
public:
	TreeNode(const Pair& p = Pair(), TreeNode* left = 0, TreeNode* right = 0) {
		data = p, leftChild = left, rightChild = right;
	}
};

//��������������
class BST {
public:
	BST() { root = 0; }
	bool IsEmpty() const;
	Pair* Get(const K&) const;
	Pair* Get(TreeNode* p, const K& k) const;
	void Insert(const Pair&);
	bool Delete(const K&,TreeNode*);
private:
	TreeNode* root;
};

//�пպ�������
bool BST::IsEmpty() const
{
	return root == 0;
}

//��ȡ�ؼ���Ϊk��pair����
Pair* BST::Get(const K & k) const
{
	return Get(root, k);
}

Pair* BST::Get(TreeNode* p, const K & k) const
{
	if (!p) return 0;
	if (k < p->data.first) return Get(p->leftChild, k);
	if (k > p->data.first) return Get(p->rightChild, k);
	return &p->data;
}

//�����½ڵ㺯��
void BST::Insert(const Pair& thePair)
{
	TreeNode* p = root, *pp = 0;
	while (p) {
		pp = p;
		if (thePair.first < p->data.first) p = p->leftChild;
		else if (thePair.first > p->data.first) p = p->rightChild;
		else // duplicate, update associated element
		{
			p->data.second = thePair.second; return;
		}
	}
	p = new TreeNode(thePair, 0, 0);
	if (root) // tree not empty
		if (thePair.first < pp->data.first) pp->leftChild = p;
		else pp->rightChild = p;
	else root = p;
}

//ɾ���ڵ�
bool BST::Delete(const K &k, TreeNode *p = 0)
{
	stack<TreeNode*> s;
	p = root;
	TreeNode* parent;
	while (p != 0)
	{
		s.push(p);
		if (p->data.first == k) {
			if (p->leftChild == 0 && p->rightChild == 0)
			{
				if (!s.empty()) {
					s.pop();
					parent = s.top();
					if (parent->leftChild == p)
						parent->leftChild = 0;
					else
						parent->rightChild = 0;
					return true;
				}
				else
					return false;
			}
			else if (p->leftChild == 0 && p->rightChild != 0)
			{
				if (!s.empty()) {
					s.pop();
					parent = s.top();
					if (parent->leftChild == p)
						parent->leftChild = p->rightChild;
					else
						parent->rightChild = p->rightChild;
					return true;
				}
				else
					return false;
			}
			else if (p->leftChild != 0 && p->rightChild == 0) 
			{
				if (!s.empty()) {
					s.pop();
					parent = s.top();
					if (parent->leftChild == p)
						parent->leftChild = p->leftChild;
					else
						parent->rightChild = p->leftChild;
					return true;
				}
				else
					return false;
			}
			else
			{
				TreeNode* n = p->rightChild;
				while (n != 0)
					n = n->leftChild;
				if (!s.empty())
				{
					s.pop();
					parent = s.top();
					if (parent->leftChild == p)
						parent->leftChild = p->rightChild;
					else
						parent->rightChild = p->rightChild;
					n->leftChild = p->leftChild;
					return true;
				}
				else
					return false;
			}
		}
		else
		{
			if (p->data.first >= k)
				p = p->leftChild;
			else
				p = p->rightChild;
		}
	}
	return false;
}

//Ԥ�������������
constexpr auto MAXLF = 0.75;

//��ϣ������
class HashTable {
public:
	HashTable(int _b = 7) :b(_b) {
		ht = new BST[b];
		fill(ht, ht + b, BST());
		D = b;
		currentNum = 0;
	}
	bool IsEmpty()const;
	Pair* Get(const K&) const;
	void Insert(const Pair&);
	void Delete(const K&);
private:
	int h(const K&)const;//��ϣ����
	double loadFactor()const;
	BST* ht;//��ϣ�����ö������������
	int b;//��ϣ��������slotΪ1
	int D;//��ϣ��������ģ
	int currentNum;//��ǰ��ϣ����Ԫ������
};

//��ϣ����
int HashTable::h(const K& k)const
{
	return k % D;
}

//���������Ӻ���
double HashTable::loadFactor() const
{
	return static_cast<double>(currentNum) / b;
}

//�пպ���
bool HashTable::IsEmpty()const
{
	for (int i = 0; i < b; i++)
	{
		if (!ht[i].IsEmpty())
			return false;
	}
	return true;
}

//��ȡ�ؼ���Ϊk��pair
Pair * HashTable::Get(const K& k) const
{
	BST* temp = &ht[h(k)];
	return temp->Get(k);
}

//���뺯��
void HashTable::Insert(const Pair& p)
{
	BST* temp = &ht[h(p.first)];
	if (loadFactor() < MAXLF)
		temp->Insert(p);
	else
	{
		BST* tempHT = ht;
		b = 2 * b + 1;
		D = b;
		ht = new BST[b];
		copy(ht, ht + b, tempHT);
		Insert(p);
	}
}

//ɾ������
void HashTable::Delete(const K& k)
{
	BST* temp = &ht[h(k)];
	if (temp->Delete(k))
		return;
	else
		cout << "�����ڹؼ�����k��ȵĽڵ㣡" << endl;
}