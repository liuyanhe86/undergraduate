#include <iostream>

using namespace std;

class Chain; // forward declaration

class ChainNode {
	friend class Chain; 
	friend class ChainIterator;

public:
	ChainNode(int element = 0, ChainNode* next = 0)
	{
		data = element; link = next;
	}
private:
	int data;
	ChainNode *link;
};

class ChainIterator {
public:

	ChainIterator(ChainNode* startNode = 0)
	{
		current = startNode;
	}

	int& operator *() const { return current->data; }
	int* operator ->() const { return &current->data; }
	ChainIterator& operator ++()
	{
		current = current->link;
		return *this;
	}
	ChainIterator& operator ++(int) // postincrement
	{
		ChainIterator old = *this;
		current = current->link;
		return old;
	}
	ChainIterator operator +(int n)
	{
		ChainIterator it = *this;
		for (int i = 0; i < n; ++i)
		{
			it++;
		}
		return it;
	}
	bool operator !=(const ChainIterator right) const
	{
		return current != right.current;
	}
	bool operator == (const ChainIterator right) const
	{
		return current == right.current;
	}
private:
	ChainNode* current;
};

class Chain {
public:
	Chain()
	{
		first = NULL;
	}
	void create();
	void output();
	int length();
	ChainIterator begin() { return ChainIterator(first); }
	ChainIterator end() { return ChainIterator(0); }
	int* Copy();
	int compute();
private:
	ChainNode *first;
};


//����ʮ���ڵ�
void Chain::create()
{
	ChainNode *tenth = new ChainNode(10, 0);
	ChainNode *nineth = new ChainNode(9, tenth);
	ChainNode *eighth = new ChainNode(8, nineth);
	ChainNode *seventh = new ChainNode(7, eighth);
	ChainNode *sixth = new ChainNode(6, seventh);
	ChainNode *fifth = new ChainNode(5, sixth);
	ChainNode *fourth = new ChainNode(4, fifth);
	ChainNode *third = new ChainNode(3, fourth);
	ChainNode *second = new ChainNode(2, third);
	first = new ChainNode(1, second);
}

//�������
void Chain::output()
{
	for (ChainNode *temp = first; temp != NULL; temp = temp->link)
		cout << temp->data << " ";
	cout << endl;
}

//�������еĽڵ���
//ʱ�临�Ӷ�ΪO(n)
int Chain::length()
{
	ChainNode *temp = first->link;
	int count = 1;
	while (temp != NULL)
	{
		temp = temp->link;
		count++;
	}
	return count;
}

//����xi*x(i+5)�ĺ�
int Chain::compute()
{
	ChainIterator front = begin();
	ChainIterator back = front+5;//����+�����
	int sum = 0;
	for (int i = 0; i < length() - 5; ++i)
	{
		sum += (*front) * (*back);
		++front;
		++back;
	}
	return sum;
}

int* Chain::Copy()
{
	ChainIterator it = begin();
	int* arr = new int[length()];
	for (int i=0;i<length();++i)
	{
		arr[i] = *it;
		it++;
	}
	return arr;
}

//���Ժ���
int main()
{
	Chain chain;
	chain.create();
	int sum = 0;
	int *arr = NULL;

	cout << "�����е�����Ϊ��";//1 2 3 4 5 6 7 8 9 10
	chain.output();
	sum = chain.compute();
	cout << "�����ܺ�Ϊ��" << sum << endl;//130

	arr = chain.Copy();
	cout << "Ŀ�������е�Ԫ��Ϊ��";
	for(int i=0;i<chain.length();++i)
	{
		cout << arr[i] << " ";
	}
	cout << endl;
	
	system("pause");
}