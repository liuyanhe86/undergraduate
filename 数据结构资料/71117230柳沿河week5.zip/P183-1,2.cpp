#include <iostream>

using namespace std;

class Chain; // forward declaration
class ChainNode {
	friend class Chain; // to make functions of Chain be able to
	// access private data members of ChainNode
public:
	ChainNode(int element = 0, ChainNode* next = 0)
	{
		data = element; link = next;
	}
private:
	int data;
	ChainNode *link;
};
class Chain {
public:
	// Chain manipulation operations
	Chain()
	{
		first = NULL;
	}
	void create();
	int length();
	void Delete(ChainNode *x);
	void output();
	ChainNode* Node(int node);
private:
	ChainNode *first;
};

//�����ĸ��ڵ�
void Chain::create()
{
	ChainNode *fourth = new ChainNode(40, 0);
	ChainNode *third = new ChainNode(30, fourth);
	ChainNode *second = new ChainNode(20, third);
	first = new ChainNode(10, second);
}

int Chain::length()//�������еĽڵ���
//ʱ�临�Ӷ�ΪO(n)
{
	ChainNode *temp = first->link;
	int count = 1;
	while (temp != NULL)
	{
		temp = temp->link;
		count++;
	}
	return count;
}

//ɾ��x���ڵ�
//ʱ�临�Ӷ�ΪO(n)
void Chain::Delete(ChainNode *x)
{
	if (x == first)
	{
		first = first->link;
		delete x;
	}
	else
	{
		for (ChainNode *temp = first; temp != x; temp = temp->link)
		{
			if (x == temp->link)
			{
				temp ->link= x->link;
				break;
			}
		}
	}
}

//�������
void Chain::output()
{
	for (ChainNode *temp = first; temp!= NULL; temp = temp->link)
		cout << temp->data << " ";
}

//���ص�node���ڵ�
ChainNode* Chain::Node(int node)
{
	ChainNode* temp = first;
	if(node>1)
		for (int i = 0; i < node-1; ++i)
			temp = temp->link;
	return temp;
}

//���Ժ���
int main()
{
	Chain chain;
	chain.create();
	cout << "���еĽڵ���Ϊ�� " << chain.length()<<endl<<endl;

	cout << "δɾ��ǰ�������е�����Ϊ��";
	chain.output(); cout << endl;
	cout << "ɾ����2���ڵ������Ϊ��";
	chain.Delete(chain.Node(2));
	chain.output(); cout << endl;

	system("pause");
}