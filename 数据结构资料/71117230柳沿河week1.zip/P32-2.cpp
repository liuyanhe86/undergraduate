#include <iostream>
using namespace std;

void printPos(int *array, int i, int n)
{
	if (i == n)
	{
		for (int j = 0; j < n; j++)
		{
			if (array[j])
				cout << "T ";
			else
				cout << "F ";
		}
		cout << endl;
	}
	else
	{
		array[i] = 0;
		printPos(array, i + 1, n);
		array[i] = 1;
		printPos(array, i + 1, n);
	}
}

int main()
{
	int n = 0;
	int frequencyCount = 0;

	cout << "Please input an integer: " << endl;
	cin >> n;

	int *pArray = new int[n];
	for (int i = 0; i < n; i++)
	{
		pArray[i] = 0;
	}

	printPos(pArray, 0, n);
	system("pause");
}