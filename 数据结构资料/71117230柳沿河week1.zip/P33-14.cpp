#include <iostream>
#include <vector>
using namespace std;

void printPowerSet(int i, vector<char> & vecA, vector<char> & vecB);
int main()
{
	cout << "Please input elements:" << endl;

	vector<char> vec;
	vector<char> vec2;

	char c;
	while (cin>>c) 
	{
		vec.push_back(c); 
	}

	cout << "\nThe powersets of your set are: " << endl;
	printPowerSet(0, vec, vec2); 
	system("pause");
}

void printPowerSet(int i, vector<char> & vec, vector<char> & vec2)
{
	if (i >= vec.size()) 
	{ 
		if (vec2.empty())
			cout << "{}" << endl; 
		else 
		{ 
			cout << "{";
			for (int j = 0; j < vec2.size(); ++j)
			{ 
				cout << vec2[j] << ", "; 
			}
			cout << "}"<<endl; 
		} 
	}
	else 
	{
		vec2.push_back(vec[i]);
		printPowerSet(i + 1, vec, vec2);
		vec2.pop_back(); 
		printPowerSet(i + 1, vec, vec2); 
	}
}
