template<class T>
class Queue {
public:
	Queue<T>(int c=10, int f=0):
		front(f), capacity(c), rear(f) {
		queue = new T[capacity];
	}

	Queue<T> split();//ʱ�临�Ӷ�ΪO(capacity/2)

	void Pop();
	void Push(const T& x);
private:
	int front, rear, capacity;
	T *queue;
};

template<class T>
Queue<T> Queue<T>::split()
{
	Queue<T> q(capacity/2);
	for (int i = front; i < capacity / 2+front; ++i)
	{
		int k = (i + 1) % capacity;
		if (i - front == rear - k)
			break;
		q.Push(queue[k]);
		Pop();
	}
	return q;
}
