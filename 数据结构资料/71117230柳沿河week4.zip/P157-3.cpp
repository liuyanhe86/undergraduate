#include <iostream>
#include <iomanip>

using namespace std;

struct offsets
{
	offsets(const int p, const int q):a(p),b(q){}
	int a, b;
};

offsets Move[8] = {offsets(-1,0),offsets(-1,1), offsets(0,1), offsets(1,1), offsets(1,0), offsets(1,-1), offsets(0,-1), offsets(-1,-1)};

int maze[14][17] =
{
	{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
	{0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1},
	{1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1},
	{1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1},
	{1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1},
	{1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1},
	{1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1},
	{1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1},
	{1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
	{1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1},
	{1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1},
	{1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1},
	{1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0},
	{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
};
int mark[14][17] = { 0 };

bool Path(int x, int y)//�ݹ��Path����
{
	if (x == 12 & y == 16)//�����յ�ʱ�����ݹ�
		return true;
	int i = 0;
	for (; i < 8; i++)//�԰˸�������������
	{
		int m = x + Move[i].a;
		int n = y + Move[i].b;
		if (maze[m][n] == 0 && mark[m][n] == 0)//�����һ�������һ�û�߹�
		{
			mark[m][n] = 1;
			if (Path(m, n))//�����һ��������Ч
				return true;
			else
				mark[m][n] = 0;//�����ⲽ���㣬ȡ�����
		}
	}
	return false;
}

int main()
{
	cout << "Path is:" << endl;
	mark[1][0] = 1;
	if (Path(1, 0))
	{
		for (int i = 0; i < 14; i++)
		{
			for (int j = 0; j < 17; j++)
			{
				if (mark[i][j])
					cout << setw(2) << mark[i][j];
				else
					cout << setw(2) << " ";
			}
			cout << endl;
		}
	}
	else
		cout << "No such way";
	system("pause");
}
