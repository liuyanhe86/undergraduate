#include <string>

using namespace std;

template<class T>
class Queue {
public:
	void Pop();
	void Push(const T& x);
	void doubling();
private:
	int front, rear, capacity;
	T *queue;
	static string LastOp;
};

static string LastOp = "Pop";

template<class T>
void Queue<T>::Pop()
{
	if (front == rear && LastOp == "Pop")
		throw "Queue is empty.Cannot delete.";
	front = (front + 1) % capacity;
	queue[front].~T();
	LastOp = "Pop";
}

template<class T>
void Queue<T>::Push(const T& x)
{
	if(front == rear && LastOp == "Push")
		doubling();
	rear = (rear + 1) % capacity;
	queue[rear] = x;
}