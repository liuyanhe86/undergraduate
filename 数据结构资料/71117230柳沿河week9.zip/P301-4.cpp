//LoserTree�������������Ӷ�ΪO(k)
void LoserTree::Build() {
		Rec* scores = buf;
		int counter = k;
		int i = 0;
		int j = counter/2;
		int m = 0;
		while (i < counter - 1) {
			if (scores[i].key > scores[i+1].key) {
				l[j] = scores[i].index;
				scores[k].key = scores[i+1].key;
			}
			else {
				l[j] = scores[i+1].index;
				scores[k].key = scores[i].key;
			}
			if (i+2 >= counter) {
				counter = counter/2;
				i = 0;
				j = (counter/2);
				m = 0;
				continue;
			}
			i+=2;
			j++;
			m++;
		}
		l[j] = scores[i].index;
		if (k % 4 == 2)
			l[0] = scores[0].index;
}