#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

class Sets {
public:
 // Set operations
	Sets(int);
	void SimpleUnion(int, int);
	int SimpleFind(int);
	void WeightedUnion(int, int);
	int CollapsingFind(int);
private:
	int *parent;
	int n; // number of set elements
};

 Sets::Sets(int numberOfElements)
{
	if (numberOfElements < 2) throw "Must have at least 2 elements.";
	n = numberOfElements;
	parent = new int[n];
	fill(parent, parent + n, -1);
}

 void Sets::SimpleUnion(int j, int i)
 { // Replace the disjoint sets with roots i and j,i != j with their union
	parent[i] = j;
 }

 int Sets::SimpleFind(int i)
 { //find the root of the tree containing element i.
	 while (parent[i] >= 0) i = parent[i];
	 return i;
 }

 void Sets::WeightedUnion(int i, int j)
 { // Union sets with roots i and j, i��j, weighting rule
 // parent[i] = - count[i] and parent[j] = - count[j]
	 int temp = parent[i] + parent[j];
	 if (parent[i] > parent[j]) { // i has fewer nodes
		 parent[i] = j;
		 parent[j] = temp;
	 }
	 else { // j has fewer nodes
		 parent[j] = i;
		 parent[i] = temp;
	 }
 }

 int Sets::CollapsingFind(int i)
 { // Find the root of tree containing element i. Use the
 // collapsing rule to collapse all nodes from i to the root.
 // find the root
	 int r = i;
	 for (; parent[r] >= 0; r = parent[r]){
		 while (i != r) {
			 int s = parent[i];
			 parent[i] = r;
			 i = s;
		 }
	 }
	 return r;
 }

 //���ܺ���
 void Performance(Sets s)
 {
	 clock_t start, end;
	 int i = 0;
	 start = clock();
	 while (i < 3000)
	 {
		 int r = rand() % 10;
		 for (int j = 0; j < r; ++j)
			 s.SimpleUnion(rand() % 100000, rand() % 100000);
		 r = rand() % 10;
		 for (int k = 0; k < r; ++k)
			 s.SimpleFind(rand() % 100000);
		 i++;
	 }
	 end = clock();
	 cout << "SimpleUnion and SimpleFind cost " << (double)(end - start) / CLOCKS_PER_SEC * 1000 << " ms.\n";
 }

 //���Ժ���
 int main()
 {
	 Sets s1(100000), s2(100000);
	 Performance(s1);
	 Performance(s2);
	 system("pause");
 }