#include <iostream>

using namespace std;

//��¼
struct Rec {
	Rec(int k = 0, int v = 0) { key = k, value = v; }
	int key, value;
};

//����������
class LoserTree {
public:
	LoserTree(int);
	void Build();
	void set(int x)
	{
		static int i = 0;
		if (i<k)
		{
			buf[i] = Rec(x);
			++i;
		}
	}
	void out()
	{
		for (int i = 0; i<k; ++i)
			cout << l[i] << " ";
		cout << endl;
	}
private:
	int k;
	int *l;
	Rec *buf;
	int getKey(int i);
	int getIndex(int i);
};

//ʤ��������
class WinnerTree {
public:
	WinnerTree(int);
	void Build();
	void set(int x)
	{
		static int i = 0;
		if (i < k)
		{
			buf[i] = Rec(x);
			++i;
		}
	}
	void out()
	{
		for (int i = 0; i < k; ++i)
			cout << l[i] << " ";
		cout << endl;
	}
private:
	int k;
	int *l;
	Rec *buf;
	int getKey(int i);
	int getIndex(int i);
};

//���������캯��
LoserTree::LoserTree(int K) {
	k = K;
	l = new int[k];
	fill(l, l + k, 0);
	buf = new Rec[k];
}

//����������
void LoserTree::Build() {
	int i;
	for (i = k - 1; i > 0; i--)
		if (getKey(2 * i) > getKey(2 * i + 1))
			l[i] = getIndex(2 * i + 1);
		else 
			l[i] = getIndex(2 * i);
	l[0] = l[1];
	for (i = 1; i < k; i++)
		if (l[i] == getIndex(2 * i))
			l[i] = getIndex(2 * i + 1);
		else
			l[i] = getIndex(2 * i);
}

//��ȡkey
int LoserTree::getKey(int i) {
	if (i < k)
		return buf[l[i]].key;
	else
		return	buf[i - k].key;
}

//��ȡindex
int LoserTree::getIndex(int i) {
	if (i < k)
		return l[i];
	else
		return (i - k);
}

//ʤ�������캯��
WinnerTree::WinnerTree(int K) {
	k = K;
	l = new int[k];
	buf = new Rec[k];
}

//ʤ��������
void WinnerTree::Build() {
	int i;
	for (i = k - 1; i > 0; i--)
		if (getKey(2 * i) > getKey(2 * i + 1))
			l[i] = getIndex(2 * i + 1);
		else
			l[i] = getIndex(2 * i);
	l[0] = l[1];
}

//��ȡkey
int WinnerTree::getKey(int i) {
	if (i < k)
		return buf[l[i]].key;
	else
		return	buf[i - k].key;
}

//��ȡindex
int WinnerTree::getIndex(int i) {
	if (i < k)
		return l[i];
	else
		return (i - k);
}

//���Ժ������ÿα�����
int main()
{
	WinnerTree wt(16);
	wt.set(4); wt.set(3); wt.set(6); wt.set(8);
	wt.set(1); wt.set(5); wt.set(7); wt.set(3);
	wt.set(2); wt.set(6); wt.set(9); wt.set(4);
	wt.set(5); wt.set(2); wt.set(5); wt.set(8);
	wt.Build();
	cout << "ʤ�������ڵ���ʤ�ߵļ�¼��������Ϊ��" << endl;
	wt.out();
	LoserTree lt(16);
	lt.set(4); lt.set(3); lt.set(6); lt.set(8);
	lt.set(1); lt.set(5); lt.set(7); lt.set(3);
	lt.set(2); lt.set(6); lt.set(9); lt.set(4);
	lt.set(5); lt.set(2); lt.set(5); lt.set(8);
	lt.Build();
	cout << "���������ڵ��Ű��ߵļ�¼��������Ϊ��" << endl;
	lt.out();
	system("pause");
}