template<class T>
//��һ���½ڵ�l��Ϊs������������
void ThreadedTree<T>::InsertLeft(ThreadedTreeNode<T>*s, ThreadedTreeNode<T>*l)
{
	if (s->leftThread)
	{
		s->leftThread = false;
		s->rightThread = false;
		s->leftChild = l;
		l->leftThread = true; l->leftChild = root;
		l->rightThread = true; l->rightChild = s;
	}
	else
	{
		l->leftChild = s->leftChild;
		l->leftThread = false; l->rightThread = true; l->rightChild = s;
		s->leftChild = l;
		ThreadedTreeNode<T> *p = l->leftChild;
		while (!p->leftThread)
			p = p->rightChild;
		p->rightChild = l;
	}
	return;
}