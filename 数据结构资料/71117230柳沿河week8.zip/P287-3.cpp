#include<iostream>

using namespace std;

template<class T>
class MaxPQ
{
public:
	virtual ~MaxPQ() {}
	virtual bool IsEmpty()const = 0;
	virtual const T& Top()const = 0;
	virtual void Push(const T&) = 0;
	virtual void Pop() = 0;
};

template<class T>
class MaxHeap : public MaxPQ<T>
{
public:
	MaxHeap(int theCapacity = 10);
	~MaxHeap() {}
	bool IsEmpty()const;
	const T& Top()const;
	void Push(const T&);
	void Pop();
	void output()const;
private:
	T* heap;
	int heapSize;
	int capacity;
};

template<class T>
MaxHeap<T>::MaxHeap(int theCapacity)
{
	if (theCapacity < 1)
		throw "Capacity must be >=1";
	capacity = theCapacity;
	heapSize = 0;
	heap = new T[capacity + 1];
}

template<class T>
bool MaxHeap<T>::IsEmpty() const
{
	return heapSize == 0;
}

template<class T>
const T & MaxHeap<T>::Top() const
{
	// TODO: �ڴ˴����� return ���
	return heap[heapSize];
}

//�Ľ����Insert������ʱ�临�Ӷ�ΪO(loglogn)(δʵ�֡���)
template<class T>
void MaxHeap<T>::Push(const T &e)
{
	if (heapSize == capacity)
	{
		capacity *= 2;
		T *temp = heap;
		heap = new T[capacity + 1];
		for (int i = 0; i < heapSize + 1; i++)
			heap[i] = temp[i];
	}
	int currentNode=++heapSize;
	while (currentNode != 1 && heap[currentNode / 2] < e)
	{
		heap[currentNode] = heap[currentNode / 2];
		currentNode /= 2;
	}
	heap[currentNode] = e;
}

template<class T>
void MaxHeap<T>::Pop()
{
	if (IsEmpty())
		throw "Heap is empty. Cannot delete.";
	heap[1].~T();

	T lastE = heap[heapSize--];

	int currentNode = 1;
	int child = 2;
	while (child <= heapSize)
	{
		if (child < heapSize&&heap[child] < heap[child + 1])
			child++;
		if (lastE >= heap[child])
			break;
		heap[currentNode] = heap[child];
		currentNode = child; child *= 2;
	}
	heap[currentNode] = lastE;
}

template<class T>
void MaxHeap<T>::output() const
{
	cout << "����Ԫ��Ϊ��";
	for (int i = 1; i <= heapSize; ++i)
		cout << heap[i] << ' ';
	cout << endl;
}

int main()
{
	MaxHeap<int> heap;
	for (int i = 1; i < 20; ++i)
		heap.Push(i);
	heap.output();
	heap.Pop();
	cout << "�����Ѷ�Ԫ�غ�";
	heap.output();
	system("pause");
}