#include<iostream>

using namespace std;

template<class T>
class MinPQ
{
public:
	virtual ~MinPQ(){}
	virtual bool IsEmpty()const = 0;
	virtual const T& Top()const = 0;
	virtual void Push(const T&) = 0;
	virtual void Pop() = 0;
};

template<class T>
class MinHeap : public MinPQ<T>
{
public:
	MinHeap(int theCapacity = 10);
	~MinHeap(){}
	bool IsEmpty()const;
	const T& Top()const;
	void Push(const T&);
	void Pop();
	void output()const;
private:
	T* heap;
	int heapSize;
	int capacity;
};

template<class T>
MinHeap<T>::MinHeap(int theCapacity)
{
	if (theCapacity < 1)
		throw "Capacity must be >=1";
	capacity = theCapacity;
	heapSize = 0;
	heap = new T[capacity + 1];
}

template<class T>
bool MinHeap<T>::IsEmpty() const
{
	return heapSize == 0;
}

template<class T>
const T & MinHeap<T>::Top() const
{
	// TODO: �ڴ˴����� return ���
	return heap[heapSize];
}

template<class T>
void MinHeap<T>::Push(const T &e)
{
	if (heapSize == capacity)
	{
		capacity *= 2;
		T *temp = heap;
		heap = new T[capacity + 1];
		for (int i = 0; i < heapSize+1; i++)
			heap[i] = temp[i];
	}
	int currentNode = ++heapSize;
	while (currentNode != 1 && heap[currentNode / 2] > e)
	{
		heap[currentNode] = heap[currentNode / 2];
		currentNode /= 2;
	}
	heap[currentNode] = e;
}

template<class T>
void MinHeap<T>::Pop()
{
	if (IsEmpty())
		throw "Heap is empty. Cannot delete.";
	heap[1].~T();

	T lastE = heap[heapSize--];

	int currentNode = 1;
	int child = 2;
	while (child <= heapSize)
	{
		if (child < heapSize&&heap[child] > heap[child+1])
			child++;
		if (lastE <= heap[child])
			break;
		heap[currentNode] = heap[child];
		currentNode = child; child *= 2;
	}
	heap[currentNode] = lastE;
}

template<class T>
void MinHeap<T>::output() const
{
	cout << "����Ԫ��Ϊ��";
	for (int i = 1; i <= heapSize; ++i)
		cout << heap[i] << ' ';
	cout << endl;
}

int main()
{
	MinHeap<int> heap;
	for (int i = 1; i < 20; ++i)
		heap.Push(i);
	heap.output();
	heap.Pop();
	cout << "�����Ѷ�Ԫ�غ�";
	heap.output();
	system("pause");
}