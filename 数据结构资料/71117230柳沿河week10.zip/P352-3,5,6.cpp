#include <algorithm>
#include <iostream>
#include <string>

using namespace std;

//���ж���
template <class T>
class Queue
{ // A finite ordered list with zero or more elements.
public:
	Queue(int queueCapacity = 10);
	// Creates an empty queue with initial capacity of
	// queueCapacity
	bool IsEmpty() const;
	T& Front() const; //Return the front element of the queue.
	T& Rear() const; //Return the rear element of the queue.
	void Push(const T& item);
	//Insert item at the rear of the queue.
	void Pop();
	// Delete the front element of the queue.
private:
	T* queue;
	int front,
		rear,
		capacity;
};

//���й��캯��
template <class T>
Queue<T>::Queue(int queueCapacity) :
	capacity(queueCapacity)
{
	if (capacity < 1) throw "Queue capacity must > 0";
	queue = new T[capacity];
	front = rear = 0;
}

//�ж϶����Ƿ�Ϊ��
template <class T>
inline bool Queue<T>::IsEmpty() const
{
	return front == rear;
}

//��ȡ����ͷ�ڵ�
template <class T>
inline T& Queue<T>::Front()const
{
	if (IsEmpty()) 
		throw "Queue is empty.No front element";
	return queue[(front + 1) % capacity];
}

//��ȡ����β�ڵ�
template <class T>
inline T& Queue<T>::Rear()const
{
	if (IsEmpty()) 
		throw "Queue is empty.No rear element";
	return queue[rear];
}

//ѹ����
template <class T>
void Queue<T>::Push(const T& x)

{ // add x at rear of queue
	if ((rear + 1) % capacity == front)
	{
		T* newQueue = new T[2 * capacity];
		// copy from queue to newQueue
		int start = (front + 1) % capacity;
		if (start < 2)
			// no wrap around
			copy(queue + start, queue + start + capacity - 1, newQueue);
		else
		{ // queue wraps around
			copy(queue + start, queue + capacity, newQueue);
			copy(queue, queue + rear + 1, newQueue + capacity - start);
		}
		// switch to newQueue
		front = 2 * capacity - 1; rear = capacity - 2; capacity *= 2;
		delete[] queue;
		queue = newQueue;
	}

	rear = (rear + 1) % capacity;
	queue[rear] = x;
}

//������
template <class T>
void Queue<T>::Pop()
{ // Delete front elemnet from queue
	if (IsEmpty()) 
		throw "Queue is empty.Cannot delete";
	front = (front + 1) % capacity;
	//queue[front]=NULL;
}

//������ǰ������
template <class T>
class Chain; 

//�����ڵ㶨��
template <class T>
class ChainNode {
	friend class Chain<T>;
public:
	ChainNode(T element, ChainNode* next = 0)
	{
		data = element; link = next;
	}
	T Data()const { return data; }
	ChainNode* Next()const { return link; }
private:
	T data;
	ChainNode *link;
};

//��������
template <class T>
class Chain {
public:
	Chain() { first = last = 0; }; // constructor initializing first to 0
	// Chain manipulation operations
	void InsertBack(const T& e);
	ChainNode<T>* First() const { return first; }
private:
	ChainNode<T> *first;
	ChainNode<T> *last;
};

//����ڵ㺯������
template <class T>
void Chain<T>::InsertBack(const T& e)
{
	if (first) { // nonempty chain
		last->link = new ChainNode<T>(e);
		last = last->link;
	}
	else first = last = new ChainNode<T>(e);
}

//linkedgraph����
class LinkedGraph {
public:
	LinkedGraph(int vertices):e(0) {
		if (vertices < 1) throw "Number of vertices must be > 0";
		n = vertices;
		adjLists = new Chain<int>[n];
	}
	void BuildList();
	void DFS() {
		visited = new bool[n]; fill(visited, visited + n, false);
		DFS(0);
		delete[]visited;
	}
	void DFS(int);
	void BFS(int=0);
	void Components();
private:
	void OutputNewComponent();
	Chain<int>* adjLists;
	bool *visited;
	bool *compare;
	int n;
	int e;
};

//��������ͼ��linked adjacency-list��ʾ
void LinkedGraph::BuildList()
{
	int v1, v2;
	while (e < n*(n - 1)) {
		cin >> v1 >> v2;
		adjLists[v1].InsertBack(v2);
		adjLists[v2].InsertBack(v1);
		e++;
	}
	cout << "Linked Adjacency-List ������ɣ�" << endl;
}

//�����ͨ�����Ķ���
void LinkedGraph::OutputNewComponent()
{
	cout << "����ͨ�����Ķ��㼯Ϊ��";
	for (int i = 0; i < n; i++)
	{
		if (visited[i] && !compare[i])
		{
			cout << i << " ";
			compare[i] = true;
		}
	}
	cout << endl;
}

//DFS��������
void LinkedGraph::DFS(int v)
{
	visited[v] = true;
	cout << v << " ";
	ChainNode<int> *p = adjLists[v].First();
	while (p)
	{
		int w = p->Data();
		if (!visited[w])
			DFS(w);
		p = p->Next();
	}
}

//BFS��������
void LinkedGraph::BFS(int v)
{
	visited = new bool[n]; fill(visited, visited + n, false);
	visited[v] = true;
	cout << v << " ";
	Queue<int> q(n);
	q.Push(v);
	ChainNode<int>* p; int w;
	while (!q.IsEmpty()) {
		v = q.Front(); q.Pop(); p = adjLists[v].First();
		while (p != 0)
		{
			w = p->Data();
			if (!visited[w]) 
			{
				visited[w] = true;
				q.Push(w);
				cout << w << " ";
			}
			p = p->Next();
		}
	} // end of while
	delete[] visited;
}

//��ͼ����ͨ��������
void LinkedGraph::Components()
{
	visited = new bool[n]; fill(visited, visited + n, false);
	compare = new bool[n]; fill(compare, compare + n, false);
	for (int i = 0; i < n; i++)
	{
		if (!visited[i]) {
			DFS(i);
			OutputNewComponent();
		}
	}
	delete[]visited;
}

//���Ժ���,���ÿα�G2����
int main()
{
	cout << "����DFS��BFS����1��\n������ͨ��������2��";
	string option;
	getline(cin, option);
	if (option == "1") {
		int v;
		cout << "����������ͼ�Ķ�������\n";
		cin >> v;
		LinkedGraph lg(v);
		cout << "����������ͼ�ı�(��㣬�յ�)��\n";
		lg.BuildList();
		cout << "DFS��·��Ϊ��\n";
		lg.DFS();
		cout << "\nBFS��·��Ϊ��\n";
		lg.BFS();
		cout << endl << endl;
		system("pause");
	}
	else if (option == "2") {
		LinkedGraph lg2(7);
		cout << "����������ͼ�ı�(��㣬�յ�)��\n";
		lg2.BuildList();
		lg2.Components();
		cout << endl;
		system("pause");
	}
}

