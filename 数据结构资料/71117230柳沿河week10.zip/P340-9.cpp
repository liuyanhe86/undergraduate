#include <iostream>

using namespace std;

template <class T> 
class Chain; // forward declaration

//�����ڵ㶨��
template <class T>
class ChainNode {
	friend class Chain<T>;
public:
	ChainNode(T element, ChainNode* next = 0)
	{
		data = element; link = next;
	}
private:
	T data;
	ChainNode *link;
};

//��������
template <class T>
class Chain {
public:
	Chain() { first = last = 0; }; // constructor initializing first to 0
	// Chain manipulation operations
	void InsertBack(const T& e);
private:
	ChainNode<T> *first;
	ChainNode<T> *last;
};

//����ڵ㺯������
template <class T>
void Chain<T>::InsertBack(const T& e)
{
	if (first) { // nonempty chain
		last->link = new ChainNode<T>(e);
		last = last->link;
	}
	else first = last = new ChainNode<T>(e);
}

//linkedgraph����
class LinkedGraph {
public:
	LinkedGraph(int vertices):e(0) {
	if (vertices < 1) throw "Number of vertices must be > 0";
		n = vertices;
		adjLists = new Chain<int>[n];
	}
	void BuildList();
 private:
	Chain<int>* adjLists;
	int n;
	int e;
};

//��������ͼ��linked adjacency-list��ʾ��ʱ�临�Ӷ�ΪO(e)��O(n*(n-1)),eΪ������nΪ������
void LinkedGraph::BuildList()
{
	int v1, v2;
	while (e<n*(n-1)) {
		cin >> v1 >> v2;
		adjLists[v1].InsertBack(v2);
		adjLists[v2].InsertBack(v1);
		e++;
	}
	cout << "������ɣ�" << endl;
}

int main()
{
	LinkedGraph lg(4);
	lg.BuildList();

	system("pause");
}
