#include <iostream>

using namespace std;

class Chain; // forward declaration
class ChainNode {
	friend class Chain; // to make functions of Chain be able to
	// access private data members of ChainNode
	friend void LinkedInsertionSort(Chain a);
public:
	ChainNode(int element = 0, ChainNode* _next = 0)
	{
		data = element; next = _next;
	}
private:
	int data;
	ChainNode *next;
};

class Chain {
public:
	// Chain manipulation operations
	Chain(){first = NULL;}
	friend void LinkedInsertionSort(Chain a);
private:
	ChainNode *first;
};

//LinkedInsertionSort��������
void LinkedInsertionSort(Chain a)
{
	ChainNode *help, *cur=a.first;
	while (cur != 0)
	{
		ChainNode *next = cur->next;//��¼��һ����㣻
		ChainNode *pre = help;//ÿ�ζ�����һ�����������ҵ� cur�����Ҫ�����λ�ã�
		while (pre->next != 0 && pre->next->data < cur->data)
		{
			pre = pre->next;
		}
		cur->next = pre->next;
		pre->next = cur;
		cur = next;
	}
}