#include <iostream>

using namespace std;

//���ж���
template <class T>
class Queue
{ // A finite ordered list with zero or more elements.
public:
	Queue(int queueCapacity = 10);
	// Creates an empty queue with initial capacity of
	// queueCapacity
	bool IsEmpty() const;
	T& Front() const; //Return the front element of the queue.
	T& Rear() const; //Return the rear element of the queue.
	void Push(const T& item);
	//Insert item at the rear of the queue.
	void Pop();
	// Delete the front element of the queue.
private:
	T* queue;
	int front,
		rear,
		capacity;
};

//���й��캯��
template <class T>
Queue<T>::Queue(int queueCapacity) :
	capacity(queueCapacity)
{
	if (capacity < 1) throw "Queue capacity must > 0";
	queue = new T[capacity];
	front = rear = 0;
}

//�ж϶����Ƿ�Ϊ��
template <class T>
inline bool Queue<T>::IsEmpty() const
{
	return front == rear;
}

//��ȡ����ͷ�ڵ�
template <class T>
inline T& Queue<T>::Front()const
{
	if (IsEmpty()) throw "Queue is empty.No front element";
	return queue[(front + 1) % capacity];
}

//��ȡ����β�ڵ�
template <class T>
inline T& Queue<T>::Rear()const
{
	if (IsEmpty()) throw "Queue is empty.No rear element";
	return queue[rear];
}

//ѹ����
template <class T>
void Queue<T>::Push(const T& x)

{ // add x at rear of queue
	if ((rear + 1) % capacity == front)
	{
		T* newQueue = new T[2 * capacity];
		// copy from queue to newQueue
		int start = (front + 1) % capacity;
		if (start < 2)
			// no wrap around
			copy(queue + start, queue + start + capacity - 1, newQueue);
		else
		{ // queue wraps around
			copy(queue + start, queue + capacity, newQueue);
			copy(queue, queue + rear + 1, newQueue + capacity - start);
		}
		// switch to newQueue
		front = 2 * capacity - 1; rear = capacity - 2; capacity *= 2;
		delete[] queue;
		queue = newQueue;
	}

	rear = (rear + 1) % capacity;
	queue[rear] = x;
}

//������
template <class T>
void Queue<T>::Pop()
{ // Delete front elemnet from queue
	if (IsEmpty()) throw "Queue is empty.Cannot delete";
	front = (front + 1) % capacity;
	//queue[front].~T;
}

class LinkedGraph;

//�����ڵ㶨��
template <class T>
class ChainNode {
	friend class LinkedGraph::TopoIterator;
public:
	ChainNode(T element=T(), ChainNode* next = 0)
	{
		data = element; link = next;
	}
private:
	T data;
	ChainNode *link;
};

//linkedgraph����
class LinkedGraph {
public:
	class TopoIterator;
	const TopoIterator& begin();
	LinkedGraph(const int& vertices) :e(0) {
		if (vertices < 1) throw "Number of vertices must be > 0";
		n = vertices;
		adjLists = new ChainNode<int>*[n];
		Indegree = new int[n];
	}
private:
	ChainNode<int>** adjLists;
	int *Indegree;
	int n;
	int e;
};

//TopoIterator����
class LinkedGraph::TopoIterator
{
public:
	TopoIterator(int _n = 0, ChainNode<int>** adjList = 0,int *_Indegree=0) :n(_n),graph(adjList),Indegree(_Indegree) 
	{ 
		q = Queue<ChainNode<int>*>(); 
		Next();
	}
	TopoIterator& operator++();
	TopoIterator& operator++(int);
	int* operator->()const;
	int& operator*()const;
private:
	ChainNode<int>** graph;
	int *Indegree;
	int n;
	ChainNode<int>* current;
	Queue<ChainNode<int>*> q;
	void Next();
};

//ָ����һ����
LinkedGraph::TopoIterator& LinkedGraph::TopoIterator::operator++()
{
	Next();
	return *this;
}

//ָ����һ����
LinkedGraph::TopoIterator& LinkedGraph::TopoIterator::operator++(int)
{
	TopoIterator it = *this;
	Next();
	return it;
}

//���ض���
int* LinkedGraph::TopoIterator::operator->()const
{
	return &current->data;
}

int & LinkedGraph::TopoIterator::operator*() const
{
	return current->data;
}

//ָ�����������Ӧ����һ����ʵ�ֺ���
void LinkedGraph::TopoIterator::Next()
{
	for (int i = 0; i < n; i++)
		if (Indegree[i] == 0)
			q.Push(graph[i]);
	if (!q.IsEmpty())
	{
		current = q.Front();
		q.Pop();
		for (ChainNode<int> *p = current; p != 0; p = p->link)
			Indegree[p->data]--;
	}
}

//��ȡ���������ͷ������
const LinkedGraph::TopoIterator & LinkedGraph::begin()
{
	return TopoIterator(n, adjLists, Indegree);
}
