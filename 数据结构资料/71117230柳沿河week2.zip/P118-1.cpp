#include <iostream>
#include <string>

using namespace std;

class String
{
public:
	String(){}
	void Frequency(string);
};

void String::Frequency(string str)
{
	int countArray[128] = { 0 };
	for (int i = 0; i<str.size(); i++)
	{
		countArray[int(str.at(i))]++;
	}
	for (int j = 0; j < 128; j++)
		if(countArray[j]!=0)
			cout << char(j) << ":" << countArray[j] << endl;
}

int main()
{
	string str("abcdadvnppptysrrfaa");
	String s;
	s.Frequency(str);
	system("pause");
}