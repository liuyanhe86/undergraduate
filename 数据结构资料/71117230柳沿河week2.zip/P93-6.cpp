#include <iostream>
#include <cmath>

using namespace std;

class Polynomial;

class Term {
	friend Polynomial;
	Term()
	{
		coef = 1;
		exp = 2;
	}
private:
	float coef;
	int exp;
};

class Polynomial
{
public:
	Polynomial(int c, int t) :capacity(c), terms(t)
	{
		termArray = new Term[capacity];
	}

	float eval(float x0)
	{
		float result = 0, term = 0;
		for (int i = 0; i < terms; i++)
		{
			term = pow(x0, termArray[i].exp);
			result += termArray[i].coef*term;
		}
		return result;
	}
private:
	Term *termArray;
	int capacity;
	int terms;
};

int main()
{
	Polynomial p(5, 3);
	cout << p.eval(1.4) << endl;
	system("pause");
}