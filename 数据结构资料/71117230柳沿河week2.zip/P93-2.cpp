#include <iostream>

using namespace std;

int compareList(int *a, size_t a_size, int *b, size_t b_size)
{
	if (a_size < b_size)
	{
		for (int i = 0; i < a_size; ++i)
		{
			if (a[i] > b[i] )
				return 1;
			else if (a[i] < b[i])
				return -1;
		}
		return -1;
	}
	else if(a_size == b_size)
	{
		for (int i = 0; i < a_size; ++i)
		{
			if (a[i] > b[i])
				return 1;
			else if (a[i] < b[i])
				return -1;
		}
		return 0;
	}
	else
	{
		for (int i = 0; i < b_size; ++i)
		{
			if (a[i] > b[i])
				return 1;
			else if (a[i] < b[i])
				return -1;
		}
		return 1;
	}
}

int main()
{
	int a[3] = { 1,2,3 }, b[3] = { 1,2,4 };
	int c = compareList(a, 3, b, 3);
	if (c == 1)
		cout << "a>b" << endl;
	else if (c == 0)
		cout << "a=b" << endl;
	else
		cout << "a<b" << endl;
	
	system("pause");
}