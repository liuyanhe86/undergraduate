#include <iostream>
#include <cmath>

using namespace std;

class Polynomial;

class Term {
	friend Polynomial;
	Term(float c=1, int e=1)
	{
		coef = c;
		exp = e;
	}
private:
	float coef;
	int exp;
};

class Polynomial
{
public:
	Polynomial(){
		start = free;
		finish = free - 1;
	}

	//������ʽ�������鳤�Ȳ���ʱ����ӱ�
	void doubleArray()
	{
		if (free == capacity - 1)
		{
			capacity *= 2;
			Term *temp = new Term[capacity];
			copy(termArray, termArray + capacity, temp);
			delete[]termArray;
			termArray = temp;
		}
	}

	//�������ʽ
	void input()
	{
		doubleArray();
		cout << "Input your polynomial's terms(coef, exp):" << endl;
		float c; int e;
		while (cin >> c >> e)
		{
			termArray[free] = Term(c, e);
			free++;//����λ�ú���
		}
		finish = free - 1;//���ý���λ��
	}

	//�������ʽ
	void output()
	{
		cout << "The polynomial is:";
		if (termArray[start].exp == 0)
		{
			cout << termArray[start].coef << endl;
			return;
		}
		if(termArray[start].coef ==1)
			cout << "x" << termArray[start].exp << " + ";
		else
			cout << termArray[start].coef << "x" << termArray[start].exp << " + ";
		for (int i = start + 1; i < finish; ++i)
		{
			if(termArray[i].coef!=1)
				cout << termArray[i].coef << "x" << termArray[i].exp << " + ";
			else
				cout << "x" << termArray[i].exp << " + ";
		}
		if (termArray[finish].exp == 0)
		{
			cout << termArray[finish].coef << endl;
			return;
		}
		cout << termArray[finish].coef << "x" << termArray[finish].exp << endl;
	}

	//����ʽ���
	Polynomial add(Polynomial pl)
	{
		doubleArray();
		Polynomial p;
		for (int i = start; i <= finish; ++i)
		{
			for (int j = pl.start; j <= pl.finish; ++j)
			{
				if (termArray[i].exp == termArray[j].exp)//ָ����ͬʱϵ�����
				{
					termArray[free].coef = termArray[i].coef + termArray[j].coef;
					termArray[free].exp = termArray[i].exp;
					free++;//����λ�ú���
				}
			}
		}
		p.finish = free - 1;//�����¶���ʽ�Ľ���λ��
		return p;
	}

	Polynomial multiply(Polynomial pl)
	{
		doubleArray();
		Polynomial p;
		for (int i = start; i <= finish; ++i)
		{
			for (int j =pl.start; j <= pl.finish; ++j)
			{
				termArray[free].exp = termArray[i].exp+termArray[j].exp;
				termArray[free].coef = termArray[i].coef*termArray[j].coef;
				free++;
				/*for (int k = ((finish > pl.finish) ? finish : pl.finish) + 1; k < free-1; ++k)
				{
					if (termArray[k].exp == termArray[free-1].exp)
					{
						termArray[k].coef += termArray[free-1].coef;
						free--;
					}
				}*/
			}
		}
		p.finish = free - 1;
		return p;
	}
	void eval(int x)
	{
		double result = 0.0;
		for (int i = start; i <= finish; ++i)
		{
			result += termArray[i].coef*pow(x, termArray[i].exp);
		}
		cout << "The result is: " << result << endl;
	}
private:
	static Term *termArray;
	static int capacity;
	static int free;
	int start, finish;
};

int Polynomial::capacity = 100;
Term* Polynomial::termArray = new Term[100];
int Polynomial::free = 0;

int main()
{
	Polynomial p1,p2;
	p1.input();
	p1.output();

	p2.input();
	p2.output();

	Polynomial p3 = p1.add(p2);
	p3.output();

	Polynomial p4 = p1.multiply(p2);
	p4.output();

	p1.eval(2);

	system("pause");
}