#include <iostream>

using namespace std;

class String {
public:
	String(const char* c, int l) :str(c), length(l) { f = new int[length]; }
	int Length() { return length; }

	//��ǿ��ʧЧ����
	void newFailureFunction()
	{
		f[0] = -1;
		for (int j = 1; j < length; j++)
		{
			int i = f[j - 1];
			while ((*(str + j) != *(str + i + 1)) && (i >= 0))
				i = f[i];
			if (*(str + j) == *(str + i + 1) && *(str + j + 1) == *(str + i + 2))//p0p1����pi=p(j-i)����pj��p(i+1)��p(j+1)
				f[j] = i + 1;
			else
				f[j] = -1;
		}//����ʱ����ȻΪO(m);
		for (int k = 0; k < length; k++)
		{
			cout << f[k] << " ";
		}
		cout << endl;
	}
	int FastFind(String pat)
	{
		int posP = 0, posS = 0;
		int lengthP = pat.Length(), lengthS = Length();
		while ((posP < lengthP) && (posS < lengthS))
		{
			if (pat.str[posP] == str[posS])
			{
				posP++; posS++;
			}
			else if (posP == 0)
				posS++;
			else
			{
				posP = pat.f[posP - 1] + 1;
			}
		}
		if (posP < lengthP)
			return -1;
		else
			return posS -lengthP;
	}
private:
	const char* str;
	int length;
	int *f;
};

int main()
{
	String s("abcabcabcacabcabcacab",21),pat("abcabcacab", 10);
	cout << "The new failure function for pat is: "; pat.newFailureFunction();

	int pos = s.FastFind(pat);//pos=11,FastFind����������ȷ
	cout << "The pos is: "<<pos << endl;
	system("pause");
}