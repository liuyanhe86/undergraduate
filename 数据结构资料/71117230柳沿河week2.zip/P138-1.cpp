#include <iostream>

using namespace std;

template<class T>
class Stack
{
private:
	T *stack;
	int top;
	int capacity;
public:
	Stack(int stackCapacity = 10);

	bool IsEmpty()const;

	T& Top()const;

	void Push(const T& item);

	void Pop();

	void outputStack();

	Stack<T> split();

	Stack<T> combine(Stack<T> s);
};

template<class T>
Stack<T>::Stack(int stackCapacity)
{
	if (stackCapacity < 1)
		throw "Stack capacity must be > 0";
	capacity = stackCapacity;
	stack = new T[capacity];
	top = -1;
}

template<class T>
bool Stack<T>::IsEmpty() const
{
	return top==-1;
}

template<class T>
T & Stack<T>::Top() const
{
	if (IsEmpty())
		throw "Stack is empty.";
	return stack[top];
}

template<class T>
void Stack<T>::Push(const T & item)
{
	if (top == capacity - 1)
	{
		cout<<"Stack is full!";
		return;
	}
	stack[++top] = item;
}

template<class T>
void Stack<T>::Pop()
{
	if (IsEmpty())
		throw "Stack is empty. Can not delete.";
	stack[top--].~T();
}

template<class T>
void Stack<T>::outputStack()
{
	for (int i = 0; i <= top; ++i)
		cout << stack[i]<<" ";
	cout << endl;
}

template<class T>
Stack<T> Stack<T>::split()
{
	if (IsEmpty() || top == -1)
		throw "Can not spilt.";
	Stack<T> temp(capacity/2);
	for (int i = 0; i <= top / 2; ++i)
	{
		temp.Push(stack[i]);
	}
	if (top % 2 == 0)
	{
		for (int j = (top / 2)-1; j >= -1; j--)
		{
			stack[j] = stack[top];
			Pop();
		}
	}
	else
	{
		for (int k = top / 2; k >= 0; k--)
		{
			stack[k] = stack[top];
			Pop();
		}
	}
	return temp;
}

template<class T>
Stack<T> Stack<T>::combine(Stack<T> s)
{
	Stack<T> temp(top + s.top + 2);
	for (int i = 0; i <= top; ++i)
	{
		temp.Push(stack[i]);
	}
	for (int j = 0; j <= s.top; ++j)
	{
		temp.Push(s.stack[j]);
	}
	return temp;
}

int main()
{
	Stack<int> s1(8), s2(8);
	for (int i = 0; i < 6; i++)
	{
		s1.Push(i);
	}
	for (int j = 0; j < 8; j++)
	{
		s2.Push(j + 6);
	}
	cout << "s1:"; s1.outputStack();
	cout << "s2:"; s2.outputStack();

	s1.Pop();
	cout << "After pop, s1 is:";
	s1.outputStack();

	s1.Push(6);
	cout << "After push, s1 is:";
	s1.outputStack();

	Stack<int> s3 = s1.split();
	cout << "After split, s1 is:"; s1.outputStack();
	cout << "s3 is:"; s3.outputStack();

	Stack<int> s4 = s1.combine(s2);
	cout << "s4 is:"; s4.outputStack();

	system("pause");
}