#include <iostream>
#include <time.h>

using namespace std;

class SparseMatrix;

class MatrixTerm {
	friend class SparseMatrix;
public:
	MatrixTerm(int r=0, int c=0, int v=0) :row(r),
		col(c),
		value(v) {}
	void change(int v)
	{
		value = v;
	}
private:
	int row, col, value;
};

//���¶���һ������������rowSize��rowStart
class row
{
	friend SparseMatrix;
public:
	row(int rsz = 0, int rst = 0)
	{
		rowSize = rsz;
		rowStart = rst;
	}
private:
	int rowSize, rowStart;
};

class SparseMatrix {
public:
	SparseMatrix(int r, int c, int t):
		rows(r),cols(c),terms(t){
		capacity = terms;
		smArray = new MatrixTerm[capacity];
	}

	//��дFastTranspose��������һ�����鴢��rowSize��rowStart
	SparseMatrix FastTranspose()
	{
		SparseMatrix b(cols, rows, terms);
		
		if (terms > 0)
		{
			row *rowArray = new row[cols];
			fill(rowArray, rowArray + cols, row());

			for (int i = 0; i < terms; i++)
				rowArray[smArray[i].col].rowSize++;

			for (int i = 0; i < cols; i++)
			{
				rowArray[i].rowStart = rowArray[i - 1].rowStart + rowArray[i - 1].rowSize;
			}

			for (int i = 0; i < terms; i++)
			{
				int j = rowArray[smArray[i].col].rowStart;
				b.smArray[j].row = smArray[i].col;
				b.smArray[j].col = smArray[i].row;
				b.smArray[j].value = smArray[i].value;
				rowArray[smArray[i].col].rowStart++;
			}
			delete[]rowArray;
		}
		return b;
	}
private:
	int rows, cols, terms, capacity;
	MatrixTerm *smArray;
};


