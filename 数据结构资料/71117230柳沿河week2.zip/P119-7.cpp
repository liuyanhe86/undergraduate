#include <iostream>

using namespace std;

class String {
public:
	String(const char* c, int l):str(c),length(l){ f = new int[length]; }
	void FailureFunction()
	{
		f[0] = -1;
		for (int j = 1; j < length; j++)
		{
			int i = f[j - 1];
			while ((*(str + j) != *(str + i + 1)) && (i >= 0))
				i = f[i];
			if (*(str + j) == *(str + i + 1))
				f[j] = i + 1;
			else
				f[j] = -1;
		}
		for (int k = 0; k < length; k++)
		{
			cout << f[k]<<" ";
		}
		cout << endl;
	}
private:
	const char* str;
	int length;
	int *f;
};

int main()
{
	String p1 ("aaaab",5), p2 ("ababaa",6), p3("abaabaabb",9);

	cout << "p1's failure function is:"; p1.FailureFunction(); cout << endl;

	cout << "p2's failure function is:"; p2.FailureFunction(); cout << endl;

	cout << "p3's failure function is:"; p3.FailureFunction(); cout << endl;

	system("pause");
}