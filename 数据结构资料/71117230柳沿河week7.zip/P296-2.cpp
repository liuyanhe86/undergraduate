#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cmath>

using namespace std;

template <class K, class E>//�ṹ��
struct Pair
{
	K first;

	E second;

	Pair(const K& k = K(), const E& e = E()) { first = k, second = e; }
};

template <class K, class E>//���ֲ�����ǰ������
class BST;

template <class K, class E>//���ڵ㶨��
class TreeNode {
	friend class BST<K,E>;
private:
	Pair<K, E> data;
	TreeNode *leftChild, *rightChild;
public:
	TreeNode(const Pair<K, E>& p=Pair<K, E>(), TreeNode* left=0, TreeNode* right=0) {
		data = p, leftChild = left, rightChild = right;
	}
};

template <class K, class E>//���ֲ���������
class BST {
public:
	BST() {}
	bool IsEmpty() const;
	Pair<K, E>* Get(const K&) const;
	Pair<K, E>* Get(TreeNode<K, E>* p, const K& k) const;
	void Insert(const Pair<K, E>&);
	int Height(TreeNode<K,E>* p = root) const;
private:
	static TreeNode<K, E>* root;
};

template <class K, class E>//��̬��Ա����
TreeNode<K, E>* BST<K, E>::root = 0;

template<class K, class E>//�ж��Ƿ�Ϊ��
bool BST<K, E>::IsEmpty() const
{
	return root==0;
}

template<class K, class E>
Pair<K, E>* BST<K, E>::Get(const K & k) const
{
	return Get(root, k);
}

template<class K, class E>
Pair<K, E>* BST<K, E>::Get(TreeNode<K, E>* p, const K & k) const
{
	if (!p) return 0;
	if (k < p->data.first) return Get(p->leftChild, k);
	if (k > p->data.first) return Get(p->rightChild, k);
	return &p->data;
}

template<class K, class E>//����һ���ڵ�
void BST<K, E>::Insert(const Pair<K, E>& thePair)
{
	TreeNode<K, E> *p = root, *pp = 0;
	while (p) {
		pp = p;
		if (thePair.first < p->data.first) p = p->leftChild;
		else if (thePair.first > p->data.first) p = p->rightChild;
		else // duplicate, update associated element
		{
			p->data.second = thePair.second; return;
		}
	}
	p = new TreeNode<K, E>(thePair, 0, 0);
	if (root) // tree not empty
		if (thePair.first < pp->data.first) pp->leftChild = p;
		else pp->rightChild = p;
	else root = p;
}

template<class K, class E>//��ȡ����
int BST<K, E>::Height(TreeNode<K, E>* p)const
{
	if (p)
	{
		int left = 0, right = 0;
		left += Height(p->leftChild);
		right += Height(p->rightChild);
		return (left > right) ? (left + 1) : (right + 1);
	}
	else
		return 0;
}

//�� height/log2(n) ����
void ratio(BST<int,int>& bst,int n)
{
	srand((unsigned)time(NULL));
	for (int i = 0; i < n; ++i)
	{
		bst.Insert(Pair<int, int>(rand(), rand()));
	}
	cout << n << "��Ӧ�� height/log2n Ϊ��" << bst.Height() / log2(n) << endl;
}

//���Ժ���
int main()
{
	BST<int,int> tree;
	ratio(tree,100500);
	for (int i = 1000; i <= 10000; i += 1000)
	{
		ratio(tree, i);
	}
	system("pause");
}
