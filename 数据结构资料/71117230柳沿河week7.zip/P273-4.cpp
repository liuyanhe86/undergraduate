template<class T>
int Tree<T>::Num_of_Leafs()//����Ҷ�ĸ�����ʱ�临�Ӷ�ΪO(n),nΪ�������нڵ����
{
	int count = 0;
	TreeNode<T>* current = root;
	if (current->leftChild == 0 && current->rightChild == 0)
	{
		count++;
	}
	else if (current->leftChild == 0)
	{
		count += Num_of_Leafs(current->rightChild);
	}
	else if (current->rightChild == 0)
	{
		count += Num_of_Leafs(current->leftChild);
	}
	else
	{
		count += Num_of_Leafs(current->leftChild);
		count += Num_of_Leafs(current->rightChild);
	}
	return count;
}
