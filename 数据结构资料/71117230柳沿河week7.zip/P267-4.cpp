#include <iostream>

using namespace std;

template<class T>
class ForwardInorderIterator {
public:
	ForwardInorderIterator() { currentNode = root; }
	T* Next();
	friend istream& operator >>(istream& is, ForwardInorderIterator<T> & it);
private:
	Stack<TreeNode<T>*> s;
	TreeNode<T> *currentNode;
};

template<class T>
T * ForwardInorderIterator<T>::Next()
{
	while (currentNode)
	{
		s.Push(currentNode);
		currentNode = currentNode->leftChild;
	}
	if (s.IsEmpty()) return 0;
	currentNode = s.Top();
	s.Pop();
	T& temp = currentNode->data;
	currentNode = currentNode->rightChild;
	return &temp;
}

template <class T>
istream & operator>>(istream & is, ForwardInorderIterator<T> & it)
{
	// TODO: �ڴ˴����� return ���
	T temp;
	cin >> temp;
	it.currentNode->data = temp;
	return is;
}
